/*
 * encoder.h
 *
 *  Created on: 17.08.2020
 *      Author: VojnovicI
 */

#ifndef DRIVER_encoder_H_
#define DRIVER_encoder_H_

/****************** Include Files ********************/

#include "xil_types.h"
#include "xstatus.h"
#include "xil_io.h"

/****************** Driver Bit Operation  ********************/

#define QUENC_S00_AXI_SLV_REG0_OFFSET 0
#define QUENC_S00_AXI_SLV_REG1_OFFSET 4
#define QUENC_S00_AXI_SLV_REG2_OFFSET 8
#define QUENC_S00_AXI_SLV_REG3_OFFSET 12

#define CLEAR_OFFSET_MASK ~(0xFFFF << 16)

#define INVERT_BIT_MASK 4
#define ICFG_MASK 3

#define CFG_TVALID_SHIFT 4
#define INV_BIT_SHIFT 2

#define SETFLAG_SHIFT 5
#define SETFLAG_MASK (0x1 << SETFLAG_SHIFT)

#define CTRVAL_MASK  (0xFFFF)
#define CTRDIR_MASK	(0x1 << 16)
#define CTRVAL_TVALID_MASK (0x1 << 17)


typedef enum  {
	indexCfg_TopValue = 0,      // -> Counter resets when max count is reached
	indexCfg_I_Rising = 1,		// -> Counter reset on Rising Edge of I
	indexCfg_AB_Rising = 2,		// -> Counter reset when I is high after Rising Edge of AB
	indexCfg_Latched = 3,		// -> Counter is zero as long as I as high
}indexCfg;


/****************** Driver Configuration ********************/

typedef struct quencConf_T{
	UINTPTR BaseAddr;		// Base Addr of AXI-Module
	u16	PulseMax; 			// Maximal Pulse of Encoder
	u16 Offset;				// encoder offset d/q-Kos Zero Offset
	indexCfg IndexCfg;		// behaviour on Index Pulse
	u8 InvertBit;			// 0 = Count Up on Rising, 1 = Count up on Falling Edge
} quencConf_t;

typedef struct quenc_T{
	u16 EncoderValRaw;
	quencConf_t Config;
} quenc_t;


int quenc_init(quenc_t * this, quencConf_t quencConf);
void quenc_setPulseMax(quenc_t* this, u16 pulseMax, u16 offset);
void quenc_setOfsset(quenc_t* this, u16 offset);
void quenc_setEncCfg(quenc_t* this, u8 iCfg, u8 invBit);
void quenc_setCounter(quenc_t* this, u16 counterRaw);
u16 quenc_getRaw(quenc_t* this);
u16 quenc_getOffset(quenc_t* this);

/**************************** Type Definitions *****************************/
/**
 *
 * Write a value to a QUENC register. A 32 bit write is performed.
 * If the component is implemented in a smaller width, only the least
 * significant data is written.
 *
 * @param   BaseAddress is the base address of the QUENCdevice.
 * @param   RegOffset is the register offset from the base to write to.
 * @param   Data is the data written to the register.
 *
 * @return  None.
 *
 * @note
 * C-style signature:
 * 	void QUENC_mWriteReg(u32 BaseAddress, unsigned RegOffset, u32 Data)
 *
 */
#define QUENC_mWriteReg(BaseAddress, RegOffset, Data) \
  	Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))

/**
 *
 * Read a value from a QUENC register. A 32 bit read is performed.
 * If the component is implemented in a smaller width, only the least
 * significant data is read from the register. The most significant data
 * will be read as 0.
 *
 * @param   BaseAddress is the base address of the QUENC device.
 * @param   RegOffset is the register offset from the base to write to.
 *
 * @return  Data is the data from the register.
 *
 * @note
 * C-style signature:
 * 	u32 QUENC_mReadReg(u32 BaseAddress, unsigned RegOffset)
 *
 */
#define QUENC_mReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))

/************************** Function Prototypes ****************************/
/**
 *
 * Run a self-test on the driver/device. Note this may be a destructive test if
 * resets of the device are performed.
 *
 * If the hardware system is not built correctly, this function may never
 * return to the caller.
 *
 * @param   baseaddr_p is the base address of the QUENC instance to be worked on.
 *
 * @return
 *
 *    - XST_SUCCESS   if all self-test code passed
 *    - XST_FAILURE   if any self-test code failed
 *
 * @note    Caching must be turned off for this function to work.
 * @note    Self test may fail if data memory and device are not on the same bus.
 *
 */
XStatus QUENC_Reg_SelfTest(void * baseaddr_p);




#endif /* DRIVER_encoder_H_ */


