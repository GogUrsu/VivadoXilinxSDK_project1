/*
 * AIT RISE 2020
 * Author: Igor Vojnovic
 * */

#include <hardware/drivers/quenc.h>

int quenc_init(quenc_t * this, quencConf_t quencConf)
{
	this->Config = (quencConf_t){
		.BaseAddr  = quencConf.BaseAddr,
		.PulseMax  = quencConf.PulseMax,
		.Offset    = quencConf.Offset,
		.IndexCfg  = quencConf.IndexCfg,
		.InvertBit = quencConf.InvertBit
	};

	quenc_setPulseMax(this, this->Config.PulseMax, this->Config.Offset);

	quenc_setEncCfg(this, this->Config.IndexCfg, this->Config.InvertBit);

	//quenc_setOfsset(quencInst, quencInst->Config.Offset);


	return XST_SUCCESS;
}

void quenc_setPulseMax(quenc_t* this, u16 pulseMax, u16 offset)
{
	u32 regValue = offset << 16;
	regValue = regValue | pulseMax;
	QUENC_mWriteReg(this->Config.BaseAddr, QUENC_S00_AXI_SLV_REG0_OFFSET, regValue);
}

//
//---------------|
// OFFSET | TOP	 |
// 31-16  | 15-0 |

void quenc_setOfsset(quenc_t* this, u16 offset)
{
	u32 regValue = QUENC_mReadReg(this->Config.BaseAddr, QUENC_S00_AXI_SLV_REG0_OFFSET);
	u32 offsetValue = offset << 16;
	regValue = regValue & CLEAR_OFFSET_MASK;
	regValue = regValue | offsetValue;
	QUENC_mWriteReg(this->Config.BaseAddr, QUENC_S00_AXI_SLV_REG0_OFFSET, regValue);
}

//QUENC_S00_AXI_SLV_REG1_OFFSET
//--------------------------------------------------------
//	| set_  | cfg_    ||  cnt- | INV_	|                |
//	| flag	| tvalid  ||  rst  | BIT    | I_CFG       	 |
//--------------------||----------------------------------
//  |	5	|   4     ||  3    |	2   |	1	 |	0	 |
//--------------------------------------------------------
void quenc_setEncCfg(quenc_t* this, indexCfg iCfg, u8 invBit)
{
	// hardcoded
	//encrst = 0 (Bit 3)
	//cfg_tvalid = 1 (Bit 4)
	u32 regValue = 0;
	regValue = (1 << CFG_TVALID_SHIFT) | (iCfg & ICFG_MASK);
	QUENC_mWriteReg(this->Config.BaseAddr, QUENC_S00_AXI_SLV_REG1_OFFSET, regValue);
}

// set Counter register
// set_flag to zero
// set_floag to one (rising edge necessary)
void quenc_setCounter(quenc_t* this, u16 counterRaw)
{
	//get set_flag
	u32 regValue = QUENC_mReadReg(this->Config.BaseAddr, QUENC_S00_AXI_SLV_REG1_OFFSET);
	u32 setFlag = ((regValue & SETFLAG_MASK) >> SETFLAG_SHIFT);
	u32 counter = (u32) counterRaw;

	if(setFlag){
		//set_flag to zero if its not zero
		regValue = regValue & (~SETFLAG_MASK);
		QUENC_mWriteReg(this->Config.BaseAddr, QUENC_S00_AXI_SLV_REG1_OFFSET, regValue);
	}
	//Set counter
	QUENC_mWriteReg(this->Config.BaseAddr, QUENC_S00_AXI_SLV_REG2_OFFSET, counter);
	//rising edge on set_flag
	regValue = regValue | SETFLAG_MASK;
	QUENC_mWriteReg(this->Config.BaseAddr, QUENC_S00_AXI_SLV_REG1_OFFSET, regValue);

}

u16 quenc_getRaw(quenc_t* this)
{
	u32 regValue = QUENC_mReadReg(this->Config.BaseAddr, QUENC_S00_AXI_SLV_REG3_OFFSET);
	this->EncoderValRaw = (u16)regValue & CTRVAL_MASK;
	return this->EncoderValRaw;
}

u16 quenc_getOffset(quenc_t* this)
{
	u32 regValue = QUENC_mReadReg(this->Config.BaseAddr, QUENC_S00_AXI_SLV_REG0_OFFSET);
	return (u16)(regValue >> 16);


}
