/*
 * AIT RISE 2020
 * Author: Igor Vojnovic
 * */

#ifndef _TIMER_H_
#define _TIMER_H_

#include "xscutimer.h"
#include "xttcps.h"



//	pTimer -> Private Timer
//	sTimer -> System Timer (TTC)

//===============================================================
// A9 - Private Timer
//===============================================================

typedef struct pTimer_T {
	XScuTimer 	Timer;
	u32 		LoadValue;
	u32 		Start;
	u32 		Stop;
}pTimer_t;

// Configuration
typedef struct pTimerConf_T {
	u8 pTimerDeviceId;
	u32 loadValue;
}pTimerConf_t;

//===============================================================
// TTC - Triple Timer Counter
//===============================================================
typedef struct sTimer_T {
	XTtcPs	Timer;
	void	(*clearIntr)(struct sTimer_T*);
} sTimer_t;

//Configuration
typedef struct sTimerConf_T {
	u16			DeviceID;
	u32			IntrId;
	u8 			IntrPrio;
	u8			IntrTrigger;
	u32 		OutputHz;
	XInterval 	Interval;
	u8 			Prescaler;
	u16			Options;
}sTimerConf_t;


//===============================================================
// A9 - Private Timer Functions
//===============================================================
int pTimer_init(pTimer_t *pTimerInst, pTimerConf_t pTimerConf);
void pTimer_start(pTimer_t *pTimerInst);
float pTimer_stop(pTimer_t *pTimerInst);
float formatTimer(pTimer_t *pTimerInst);

//===============================================================
// TTC - Triple Timer Counter Functions
//===============================================================
int sTimer_init(sTimer_t *sTimerInst, sTimerConf_t sTimerConf);
void sTimer_enableInvervalIntr(sTimer_t *sTimerInst);
void sTimer_enableOverflowIntr(sTimer_t *sTimerInst);
void sTimer_clearInterrupt(sTimer_t* sTimerInst);
void sTimer_start(sTimer_t *sTimerInst);
void sTimer_stop(sTimer_t *sTimerInst);

#endif

