/*
 * AIT RISE 2020
 * Author: Igor Vojnovic
 * */

#ifndef _GIC_H_
#define _GIC_H_

#include "xscugic.h"

typedef struct gic_T{
	XScuGic Gic;
}gic_t;

// Holds
typedef struct gicConf_T{
	u32 ICDISR0;
	u32 ICDISR1;
	u32 ICDISR2;
} gicConf_t;


//Public
int gic_init(gic_t* gicInst, u32 *IRQList, u16 IRQListLen);
int gic_IntrList(gicConf_t* conf, u32 *intrList, u16 intrListLen);
int gic_addHandler(gic_t* gicInst, u32 intr_id, u32 intr_prio, u32 intr_trigger, Xil_InterruptHandler Handler, void* CallBackRef);
//Private
void gic_enableExceptions();
void gic_disableExceptions();
s32 XScuGic_CfgInitialize_CUSTOM(XScuGic *InstancePtr,XScuGic_Config *ConfigPtr, gicConf_t *gicConf);
#endif
