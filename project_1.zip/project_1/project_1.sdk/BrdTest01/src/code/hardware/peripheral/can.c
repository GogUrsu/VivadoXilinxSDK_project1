/*
 * AIT RISE 2020
 * Author: Igor Vojnovic
 * */

#include "hardware/peripheral/can.h"

#include "app/app.h"

int can_init(can_t *canInst, gic_t *InterruptController, canConf_t canConf, void (*recvCallback)(u16 canID, u8* recvBuffer)){

	int status;
	XCanPs_Config *ConfigPtr;
	XCanPs * InstPtr =  &canInst->CanInst;
	canInst->recvCallback = recvCallback;

	canInst->Watchdog = 0;

    //===============================================================
    // init CAN
    //===============================================================

	//get can config
	ConfigPtr = XCanPs_LookupConfig(canConf.canDeviceId);
	if (ConfigPtr == NULL) {
		LOG("ERROR: Can-init LookupConfigError");
		return XST_FAILURE;
	}

	//init can
	status = XCanPs_CfgInitialize(InstPtr,
					ConfigPtr,
					ConfigPtr->BaseAddr);
	if (status != XST_SUCCESS) {
		LOG("ERROR: Can-init Config Initialize");
		return XST_FAILURE;
	}

	//selftest can
	status = XCanPs_SelfTest(InstPtr);
	if (status != XST_SUCCESS){
		LOG("ERROR: Can-init SelfTest");
		return XST_FAILURE;
	}

    //===============================================================
    // Configure CAN
    //===============================================================

	// Enter Configuration Mode so we can setup Baud Rate Prescaler
	// Register (BRPR) and Bit Timing Register (BTR).
	XCanPs_EnterMode(InstPtr, XCANPS_MODE_CONFIG);
	while(XCanPs_GetMode(InstPtr) != XCANPS_MODE_CONFIG);



	//Setup Baud Rate Prescaler Register (BRPR) and
	//Bit Timing Register (BTR).
	XCanPs_SetBaudRatePrescaler(InstPtr, canConf.baudRatePrescaler);
	XCanPs_SetBitTiming(InstPtr, canConf.syncJumpWidth,
					canConf.secondTimingSegment,
					canConf.firstTimingSegment);

	//Set interrupt handlers.
	XCanPs_SetHandler(InstPtr, XCANPS_HANDLER_SEND,
			(void *)SendHandler, (void *)canInst);
	XCanPs_SetHandler(InstPtr, XCANPS_HANDLER_RECV,
			(void *)RecvHandler, (void *)canInst);
	XCanPs_SetHandler(InstPtr, XCANPS_HANDLER_ERROR,
			(void *)ErrorHandler, (void *)canInst);
	XCanPs_SetHandler(InstPtr, XCANPS_HANDLER_EVENT,
			(void *)EventHandler, (void *)canInst);

	/*
	 * Connect the device driver handler that will be called when an
	 * interrupt for the device occurs, the handler defined above performs
	 * the specific interrupt processing for the device.
	 */
	//ToDo: change to gic_addHandler()
	gic_disableExceptions();

	XScuGic_SetPriorityTriggerType(&InterruptController->Gic, canConf.intrId, canConf.IntrPrio, canConf.IntrTrigger);

	status = XScuGic_Connect(&InterruptController->Gic, canConf.intrId,
				(Xil_InterruptHandler)XCanPs_IntrHandler,
				(void *)InstPtr);
	if (status != XST_SUCCESS) {
		LOG("ERROR: Can-init gic handler");
		return XST_FAILURE;
	}

	//Clear all pending CAN interrupts
	XCanPs_IntrClear(InstPtr, 0x7FFF);

	//Enter CAN normal Mode.
	XCanPs_EnterMode(InstPtr, XCANPS_MODE_NORMAL);
	while(XCanPs_GetMode(InstPtr) != XCANPS_MODE_NORMAL);

	//Enable the interrupt for the CAN device.
	XScuGic_InterruptMaptoCpu(&InterruptController->Gic, (u8)XPAR_CPU_ID, canConf.intrId);
	XScuGic_Enable(&InterruptController->Gic, canConf.intrId);

	gic_enableExceptions();

	//Enable XCANPS_IXR_RXNEMP_MASK interrupt in CAN device. (XCANPS_IXR_ALL)
	XCanPs_IntrEnable(InstPtr, XCANPS_IXR_ALL);

	// Disable the Receive FIFO Not Empty Interrupt and the
	// New Message Received Interrupt.
	/*XCanPs_IntrDisable(InstPtr,
			XCANPS_IXR_TXFLL_MASK |
			XCANPS_IXR_TXOK_MASK |
			XCANPS_IXR_TXOK_MASK);
	 0*/

	return XST_SUCCESS;
}

static void SendHandler(void *CallBackRef){

}

static void RecvHandler(void *CallBackRef){

	int status;
	can_t *canInst = (can_t *)CallBackRef;
	u8 *FramePtr;
	u16 id;

	status = XCanPs_Recv(&canInst->CanInst, &canInst->RxFrame[0]);

	id = GET_STD_ID(canInst->RxFrame[0]);
	FramePtr = (u8 *)(&canInst->RxFrame[2]);

	canInst->recvCallback(id, FramePtr);

	return;

}

static void EventHandler(void *CallBackRef, u32 IntrMask){

}

static void ErrorHandler(void *CallBackRef, u32 ErrorMask){

}

int SendFrame(can_t *this, const u8 * data, u32 message_id)
{
	u8 *FramePtr;
	int Index;
	int Status;
	int timeout = 0;
	XCanPs *InstancePtr = &this->CanInst;

	/*
	 * Create correct values for Identifier and Data Length Code Register.
	 */
	this->TxFrame[0] = (u32)XCanPs_CreateIdValue((u32)message_id, 0, 0, 0, 0);
	this->TxFrame[1] = (u32)XCanPs_CreateDlcValue((u32)FRAME_DATA_LENGTH);

	/*
	 * Now fill in the data field with known values so we can verify them
	 * on receive.
	 */

	FramePtr = (u8 *)(&this->TxFrame[2]);
	for (Index = 0; Index < FRAME_DATA_LENGTH; Index++) {
		*FramePtr++ = *data;
		data++;
	}

	/*
	 * Wait until TX FIFO has room.
	 */
	while (XCanPs_IsTxFifoFull(InstancePtr) == TRUE){
		timeout++;
		if(timeout > 200){
			return XST_FIFO_NO_ROOM;
		}

	}

	/*
	 * Now send the frame.
	 *
	 * Another way to send a frame is keep calling XCanPs_Send() until it
	 * returns XST_SUCCESS. No check on if TX FIFO is full is needed anymore
	 * in that case.
	 */
	if(InstancePtr == NULL)
	{
		printf("abc");
	}
	Status = XCanPs_Send(InstancePtr, this->TxFrame);

	return Status;
}
