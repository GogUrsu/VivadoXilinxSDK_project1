/*
 * AIT RISE 2020
 * Author: Igor Vojnovic
 * */

#include "hardware/peripheral/gic.h"

#include "app/app.h"

int gic_init(gic_t* gicInst, u32 *IRQList, u16 IRQListLen){

	XScuGic_Config *XScuGicConfig;
	gicConf_t GicConf;
	GicConf.ICDISR0 = 0;
	GicConf.ICDISR1 = 0;
	GicConf.ICDISR2 = 0;

	int status;

	//init diag
	XScuGicConfig = XScuGic_LookupConfig(XPAR_PS7_SCUGIC_0_DEVICE_ID);
    if (XScuGicConfig == NULL){
		LOG("ERROR: GIC-init LookupConfigError");
		return XST_FAILURE;
    }

    //Get IRQ List
    gic_IntrList(&GicConf, IRQList, IRQListLen);

	// Init Global Interrupt Controller
    //status = XScuGic_CfgInitialize(&gicInst->Gic, XScuGicConfig, XScuGicConfig->CpuBaseAddress);
    status = XScuGic_CfgInitialize_CUSTOM(&gicInst->Gic, XScuGicConfig, &GicConf);

    if (status != XST_SUCCESS) {
		LOG("ERROR: GIC-init LookupConfigError");
		return XST_FAILURE;
	}
	//init gic
	//XScuGic_CPUWriteReg(&gicInst->Gic, XSCUGIC_BIN_PT_OFFSET, 0x03);
	Xil_ExceptionInit();

	// Reconfigure GIC to use FIQ and let both be managed by GIC
	//XScuGic_CPUWriteReg(&gicInst->Gic, XSCUGIC_CONTROL_OFFSET, 0x0FU);

	// Configure Exeption Handling for IRQ
	Xil_ExceptionRegisterHandler(XIL_EXCEPTION_ID_FIQ_INT,
			 	 	 	 	 	 (Xil_ExceptionHandler)XScuGic_InterruptHandler,
								 (void *)&gicInst->Gic);

	// Configure Exeption Handling for FIQ
	Xil_ExceptionRegisterHandler(XIL_EXCEPTION_ID_IRQ_INT,
			 	 	 	 	 	 (Xil_ExceptionHandler)XScuGic_InterruptHandler,
								 (void *)&gicInst->Gic);

	//Enable FIQ and IRQ
	gic_enableExceptions();

	return XST_SUCCESS;
}

/*
 * 	Connect handler to interrupt source and enable interrupts
 *
 * */
int gic_addHandler(gic_t* gicInst, u32 intr_id, u32 intr_prio, u32 intr_trigger, Xil_InterruptHandler Handler, void* CallBackRef){
	int status;

	gic_disableExceptions();

	//set priority and trigger type for interupt id
	XScuGic_SetPriorityTriggerType(&gicInst->Gic, intr_id, intr_prio, intr_trigger);

	// Connect Interrupt Handler - for ADCMiddleware Interrupt
	status = XScuGic_Connect(&gicInst->Gic,
	    					 intr_id,
							 (Xil_ExceptionHandler)Handler,
							 CallBackRef);
	if (status != XST_SUCCESS) {
		LOG("ERROR: GIC Interrupt Handler Connection ");
		return XST_FAILURE;
	}

	// Enable Interrupt Source
	XScuGic_InterruptMaptoCpu(&gicInst->Gic, (u8)XPAR_CPU_ID, intr_id);
	XScuGic_Enable(&gicInst->Gic, intr_id);

	gic_enableExceptions();

	return status;
}


void gic_enableExceptions(){
	Xil_ExceptionEnableMask(XIL_EXCEPTION_ALL);
	//Xil_ExceptionEnableMask(XREG_CPSR_IRQ_ENABLE);
}

void gic_disableExceptions(){
	Xil_ExceptionDisableMask(XIL_EXCEPTION_ALL);
	//Xil_ExceptionDisableMask(XREG_CPSR_IRQ_ENABLE);
}

int gic_IntrList(gicConf_t* conf, u32 *intrList, u16 intrListLen)
{
	u16 i=0;
	for(;i<intrListLen;i++){
		//GetRegister
		/* TODO Remove stupid switch, change structure to array*/
		u16 shift = (intrList[i] % 32);
		switch((intrList[i]/32U)){
		case 0:
			conf->ICDISR0 |= (1U << shift);
			break;
		case 1:
			conf->ICDISR1 |= (1U << shift);
			break;
		case 2:
			conf->ICDISR2 |= (1U << shift);
			break;
		default:
			//TODO: ERROR
			break;
		}
	}
	return XST_SUCCESS;

}


/*****************************************************************************/
/**
*
* A stub for the asynchronous callback. The stub is here in case the upper
* layers forget to set the handler.
*
* @param	CallBackRef is a pointer to the upper layer callback reference
*
* @return	None.
*
* @note		None.
*
*********************************************************************/

static void StubHandler(void *CallBackRef){
	/*
	 * verify that the inputs are valid
	 */
	Xil_AssertVoid(CallBackRef != NULL);

	/*
	 * Indicate another unhandled interrupt for stats
	 */
	((XScuGic *)((void *)CallBackRef))->UnhandledInterrupts++;
}


s32 XScuGic_CfgInitialize_CUSTOM(XScuGic *InstancePtr,XScuGic_Config *ConfigPtr, gicConf_t *gicConf){


	u32 Int_Id;

	if(InstancePtr->IsReady != XIL_COMPONENT_IS_READY) {

		InstancePtr->IsReady = 0U;
		InstancePtr->Config = ConfigPtr;


		for (Int_Id = 0U; Int_Id < XSCUGIC_MAX_NUM_INTR_INPUTS;
				Int_Id++) {
			/*
			* Initialize the handler to point to a stub to handle an
			* interrupt which has not been connected to a handler
			* Only initialize it if the handler is 0 which means it
			* was not initialized statically by the tools/user. Set
			* the callback reference to this instance so that
			* unhandled interrupts can be tracked.
			*/
			if ((InstancePtr->Config->HandlerTable[Int_Id].Handler
					== (Xil_InterruptHandler)NULL)) {
				InstancePtr->Config->HandlerTable[Int_Id].Handler
						= (Xil_InterruptHandler)StubHandler;
			}
			InstancePtr->Config->HandlerTable[Int_Id].CallBackRef =
								InstancePtr;
		}


		XScuGic_Stop(InstancePtr);
		//========================================================================================================
		// START DistributorInit(InstancePtr);
		//========================================================================================================
		// Disable
		XScuGic_DistWriteReg(InstancePtr, XSCUGIC_DIST_EN_OFFSET, 0U);


		/*
		 * Set the security domains in the int_security registers for
		 * non-secure interrupts
		 * All are secure, so leave at the default. Set to 1 for non-secure
		 * interrupts.
		 */


		// Configure XPAR_XTTCPS_5_INTR as non-secure -> IRQ
		//XScuGic_DistWriteReg(InstancePtr,XSCUGIC_SECURITY_TARGET_OFFSET_CALC(XPAR_XTTCPS_5_INTR), ( 1U << (XPAR_XTTCPS_5_INTR % 32) )  |  ( 1U << (XPAR_XTTCPS_4_INTR % 32) ) );
		// Write ICDISRx
		XScuGic_DistWriteReg(InstancePtr, (u32)XSCUGIC_SECURITY_OFFSET		 , gicConf->ICDISR0);
		XScuGic_DistWriteReg(InstancePtr, (u32)XSCUGIC_SECURITY_OFFSET + 0x4U, gicConf->ICDISR1);
		XScuGic_DistWriteReg(InstancePtr, (u32)XSCUGIC_SECURITY_OFFSET + 0x8U, gicConf->ICDISR2);

#define XSCUGIC_SECURITY_TARGET_OFFSET_CALC(InterruptID) \
	((u32)XSCUGIC_SECURITY_OFFSET + (((InterruptID)/32U)*4U))

		//XScuGic_DistWriteReg(InstancePtr,XSCUGIC_SECURITY_TARGET_OFFSET_CALC(XPAR_XTTCPS_4_INTR), ( 1U << (XPAR_XTTCPS_5_INTR % 32) )  |  ( 1U << (XPAR_XTTCPS_4_INTR % 32) ) );

		/*
		 * For the Shared Peripheral Interrupts INT_ID[MAX..32], set:
		 */

		/*
		 * 1. The trigger mode in the int_config register
		 * Only write to the SPI interrupts, so start at 32
		 */
		for (Int_Id = 32U; Int_Id < XSCUGIC_MAX_NUM_INTR_INPUTS;
				Int_Id = Int_Id+16U) {
			/*
			 * Each INT_ID uses two bits, or 16 INT_ID per register
			 * Set them all to be level sensitive, active HIGH.
			 */
			XScuGic_DistWriteReg(InstancePtr,
						XSCUGIC_INT_CFG_OFFSET_CALC(Int_Id),
						0U);
		}


		#define DEFAULT_PRIORITY    0xa0a0a0a0U
		for (Int_Id = 0U; Int_Id < XSCUGIC_MAX_NUM_INTR_INPUTS;
				Int_Id = Int_Id+4U) {
			/*
			 * 2. The priority using int the priority_level register
			 * The priority_level and spi_target registers use one byte per
			 * INT_ID.
			 * Write a default value that can be changed elsewhere.
			 */
			XScuGic_DistWriteReg(InstancePtr,
						XSCUGIC_PRIORITY_OFFSET_CALC(Int_Id),
						DEFAULT_PRIORITY);
		}

		for (Int_Id = 0U; Int_Id<XSCUGIC_MAX_NUM_INTR_INPUTS;Int_Id=Int_Id+32U) {
			/*
			 * 4. Enable the SPI using the enable_set register. Leave all
			 * disabled for now.
			 */
			XScuGic_DistWriteReg(InstancePtr,
			XSCUGIC_EN_DIS_OFFSET_CALC(XSCUGIC_DISABLE_OFFSET, Int_Id),
				0xFFFFFFFFU);

		}


		// DISTRIBUTOR - Enable Secure and Non Secure
		XScuGic_DistWriteReg(InstancePtr, XSCUGIC_DIST_EN_OFFSET, 0x3U);

		//========================================================================================================
		// END DistributorInit
		//========================================================================================================

		//========================================================================================================
		// START CPUInitialize(InstancePtr);
		//========================================================================================================


		/*
		 * Program the priority mask of the CPU using the Priority mask register
		 */
		XScuGic_CPUWriteReg(InstancePtr, XSCUGIC_CPU_PRIOR_OFFSET, 0xF0U);


		/*
		 * If the CPU operates in both security domains, set parameters in the
		 * control_s register.
		 * 1. Set FIQen=1 to use FIQ for secure interrupts,
		 * 2. Program the AckCtl bit
		 * 3. Program the SBPR bit to select the binary pointer behavior
		 * 4. Set EnableS = 1 to enable secure interrupts
		 * 5. Set EnbleNS = 1 to enable non secure interrupts
		 */
		XScuGic_CPUWriteReg(InstancePtr, XSCUGIC_CONTROL_OFFSET, 0x1FU);

		/*
		 * If the CPU operates only in the secure domain, setup the
		 * control_s register.
		 * 1. Set FIQen=1,
		 * 2. Set EnableS=1, to enable the CPU interface to signal secure
		 *  interrupts. Only enable the IRQ output unless secure interrupts
		 * are needed.
		 */
		//XScuGic_CPUWriteReg(InstancePtr, XSCUGIC_CONTROL_OFFSET, 0x07U);


		//========================================================================================================
		// END CPUInitialize
		//========================================================================================================


		InstancePtr->IsReady = XIL_COMPONENT_IS_READY;
	}

	return XST_SUCCESS;


}
