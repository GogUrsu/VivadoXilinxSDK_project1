/*
 * AIT RISE 2020
 * Author: Igor Vojnovic
 * */

#include "hardware/peripheral/timer.h"
#include "xtime_l.h"

#include "app/app.h"


int pTimer_init(pTimer_t *pTimerInst, pTimerConf_t pTimerConf){

	int status;
	XScuTimer_Config * ConfigPtr;
	XScuTimer *InstPtr = &pTimerInst->Timer;

    //===============================================================
    // init private timer
    //===============================================================

	//get pTimer config
	ConfigPtr = XScuTimer_LookupConfig(pTimerConf.pTimerDeviceId);
	if (ConfigPtr == NULL) {
		LOG("ERROR: Timer-init LookupConfigError");
		return XST_FAILURE;
		}

	//init pTimer
	status = XScuTimer_CfgInitialize(InstPtr,
					ConfigPtr,
					ConfigPtr->BaseAddr);
	if (status != XST_SUCCESS) {
		LOG("ERROR: Timer-init Config Init");
		return XST_FAILURE;
	}

	//===============================================================
	// Configure private timer
	//===============================================================
	pTimerInst->LoadValue = pTimerConf.loadValue;
	pTimerInst->Start = 0;
	pTimerInst->Stop = 0;
	return XST_SUCCESS;
}

void pTimer_start(pTimer_t *pTimerInst){
	XScuTimer_LoadTimer(&pTimerInst->Timer, pTimerInst->LoadValue);
	pTimerInst->Start = XScuTimer_GetCounterValue(&pTimerInst->Timer);
	XScuTimer_Start(&pTimerInst->Timer);
}

float pTimer_stop(pTimer_t *pTimerInst){

	XScuTimer_Stop(&pTimerInst->Timer);
	pTimerInst->Stop = XScuTimer_GetCounterValue(&pTimerInst->Timer);
	XScuTimer_LoadTimer(&pTimerInst->Timer, pTimerInst->LoadValue);
	return formatTimer(pTimerInst);
}

float formatTimer(pTimer_t *pTimerInst){
	float timer_value = pTimerInst->Start - pTimerInst->Stop;
	return (float) timer_value/COUNTS_PER_SECOND;
}

	int status;
int sTimer_init(sTimer_t *sTimerInst, sTimerConf_t sTimerConf){
	XTtcPs_Config *ConfigPtr;
	XTtcPs *InstPtr = &sTimerInst->Timer;
	u8 Prescaler;
	XInterval Interval;

	//===============================================================
	// init ttc
	//===============================================================
	ConfigPtr = XTtcPs_LookupConfig(sTimerConf.DeviceID);
	if (ConfigPtr == NULL) {
			LOG("ERROR: Timer-init LookupConfigError");
			return XST_FAILURE;
	}

	status = XTtcPs_CfgInitialize(InstPtr,
					ConfigPtr,
					ConfigPtr->BaseAddress);
	if (status != XST_SUCCESS) {
		LOG("ERROR: Timer-init Config Init");
		return XST_FAILURE;
	}

	//Add InterruptClear Function to Datacontainer
	sTimerInst->clearIntr = sTimer_clearInterrupt;

	//===============================================================
	// Configure ttc
	//===============================================================
	//Set timer options
	XTtcPs_SetOptions(InstPtr, sTimerConf.Options);


	// Calculate Inverval and Prescaler from OutputHz
	// configure ttc module
	XTtcPs_CalcIntervalFromFreq(InstPtr, sTimerConf.OutputHz, &Interval, &Prescaler);
	XTtcPs_SetInterval(InstPtr, Interval);
	XTtcPs_SetPrescaler(InstPtr, Prescaler);

	return XST_SUCCESS;
}

void sTimer_enableInvervalIntr(sTimer_t *sTimerInst){
	XTtcPs_EnableInterrupts(&sTimerInst->Timer, XTTCPS_IXR_INTERVAL_MASK);
}

void sTimer_enableOverflowIntr(sTimer_t *sTimerInst){
	XTtcPs_EnableInterrupts(&sTimerInst->Timer, XTTCPS_IXR_CNT_OVR_MASK);
}

void sTimer_clearInterrupt(sTimer_t* sTimerInst){
	u32 StatusEvent;
	//Read the interrupt status, then write it back to clear the interrupt.
	StatusEvent = XTtcPs_GetInterruptStatus(&sTimerInst->Timer);
	XTtcPs_ClearInterruptStatus(&sTimerInst->Timer, StatusEvent);
}


void sTimer_start(sTimer_t *sTimerInst){
	// ToDo do plausibility with XTtcPs_IsStarted -> Diag
	XTtcPs_Start(&sTimerInst->Timer);
}

void sTimer_stop(sTimer_t *sTimerInst){
	// ToDo do plausibility with XTtcPs_IsStarted -> Diag
	XTtcPs_Stop(&sTimerInst->Timer);
}
