/*
 * AIT RISE 2020
 * Author: Igor Vojnovic
 * */

#ifndef _CAN_H_
#define _CAN_H_

#include "xcanps.h"

#include "xparameters.h"
#include "hardware/peripheral/gic.h"

//Frame Data field length
#define FRAME_DATA_LENGTH 		8

#define GET_STD_ID(IDR) (((IDR) >> XCANPS_IDR_ID1_SHIFT) & 0x7FF )

//RX and TX Buffer, TRM_UG585 Page 570: 4 Words  32 Bit -> 16 Bytes
#define BUFFER_32BIT_WORD 4
//static u32 TxFrame[BUFFER_32BIT_WORD];
//static u32 RxFrame[BUFFER_32BIT_WORD];


typedef struct can_T{
	XCanPs CanInst;
	void (*recvCallback)(u16 canID, u8* recvBuffer);
	u32 TxFrame[BUFFER_32BIT_WORD];
	u32 RxFrame[BUFFER_32BIT_WORD];
	u16 Watchdog;
}can_t;

// --> callback for recv can messages -> appcan.h/.c
extern void canapp_recvCallback(u16 canID, u8* recvBuffer);

//===============================================================
// CAN Configuration
//===============================================================
typedef struct canConf_T{
	u8	canDeviceId;
	u8  baudRatePrescaler;
	u8 	syncJumpWidth;
	u8 	firstTimingSegment;
	u8  secondTimingSegment;
	u32	intrId;
	u8  IntrPrio;
	u8  IntrTrigger;
}canConf_t;

// Init Functions
int can_init(can_t *canInst, gic_t *InterruptController, canConf_t canConf, void (*recvCallback)(u16 canID, u8* recvBuffer));
// Functional Functions
static void SendHandler(void *CallBackRef);
static void RecvHandler(void *CallBackRef);
static void EventHandler(void *CallBackRef, u32 IntrMask);
static void ErrorHandler(void *CallBackRef, u32 ErrorMask);
int SendFrame(can_t *this, const u8 * data, u32 message_id);

#endif
