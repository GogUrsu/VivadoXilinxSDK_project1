/*
 * AIT RISE 2020
 * Author: Igor Vojnovic
 * */

#include "hardware/peripheral/gpio.h"

#include "app/app.h"

int gpio_EMIO_init(gpio_t *gpioInst, gpioEMIOConf_t gpioEMIOConf)
{
	int status;
	XGpioPs_Config *ConfigPtr;
	XGpioPs * InstPtr = &gpioInst->GPIOPtr;

    //===============================================================
    // init GPIO
    //===============================================================

	//get gpio config
	ConfigPtr = XGpioPs_LookupConfig(gpioEMIOConf.GPIODeviceID);
	if (ConfigPtr == NULL) {
		LOG("ERROR: GPIO-init LookupConfig");
		return XST_FAILURE;
	}

	//init gpio
	status = XGpioPs_CfgInitialize(InstPtr,
					ConfigPtr,
					ConfigPtr->BaseAddr);
	if (status != XST_SUCCESS) {
		LOG("ERROR: GPIO-init Config Init");
		return XST_FAILURE;
	}

	return XST_SUCCESS;
}
