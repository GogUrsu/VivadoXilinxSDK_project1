/*
 * AIT RISE 2020
 * Author: Igor Vojnovic
 * */

#ifndef _GPIO_H_
#define _GPIO_H_

#include "xgpiops.h"
#include "xparameters.h"


typedef struct gpio_T {
	XGpioPs		GPIOPtr;
}gpio_t;

typedef struct gpioEMIOConf_T{
	u8 		GPIODeviceID;
	u8		test;
}gpioEMIOConf_t;

typedef enum {
	gpioDirection_In  = 0, 	// 0
	gpioDirection_Out = 1 	// 1
} gpioDirection;

typedef struct gpioPin_T{
	u8	PinId;
	gpioDirection PinDirection;
}gpioPin_t;


int gpio_EMIO_init(gpio_t *gpioInst, gpioEMIOConf_t gpioEMIOConf);

#endif
