/*
 * AIT RISE 2020
 * Author: Igor Vojnovic
 * */

#ifndef _MONITORING_H_
#define _MONITORING_H_

#include "hardware/peripheral/timer.h"
#include "hardware/peripheral/gpio.h"

//
//	Monitoring Module is a collection of functions for
//  software monitoring (timer for cycle time etc.)
//  or debugging capabilities (gpio pin toggling)
//  and realtime controller debugging


// DEBUG PINS CONFIG
#define DEBUG_PINS	4
// TODO DEBUG_PINS MACRO NOT AT SAME POS AS DEFINITION; CHANGE POSITION IN CODE -> MACRO IS OVERLOOKED easily!!!
#define CTRL_DEBUG_VALUES_COUT 3000
#define CTRL_DEBUG_VALUES_VARS 14


typedef enum {
	DebugPin0 = 0,
	DebugPin1 = 1,
	DebugPin2 = 2,
	DebugPin3 = 3
} DebugPinAlias;

typedef enum {
	cntlDebugState_write,
	ctrlDebugState_read
} ctrlDebugState;

typedef enum{
	ctrlDebugTrigger_active,
	ctrlDebugTrigger_inactive,
} ctrlDebugTrigger;


typedef struct ctrlDebug_T{
	ctrlDebugState state;
	u16	index;
	u16 maxCount;
	u16 maxVars;
	float ValueArray[CTRL_DEBUG_VALUES_VARS][CTRL_DEBUG_VALUES_COUT];
	float appendArray[CTRL_DEBUG_VALUES_VARS];
	// -- read
	u16 readCurrIndex;
	u16 readCounter;
	float readArray[CTRL_DEBUG_VALUES_VARS];
	// -- trigger
	ctrlDebugTrigger trigger;
	u16 triggerCounter;
}ctrlDebug_t;

typedef struct monitoring_T {
	//--- control loop timer
	pTimer_t		LoopTimer;
	float			LoopDuration;
	// --- debugging Pins
	gpio_t			*gpioPtr;
	gpioPin_t		DebugPins[DEBUG_PINS];
	// --- cntl debug
	ctrlDebug_t ctrlDebug;
}monitoring_t;


void mon_init(monitoring_t *inst);
void mon_debugGPIO_init(monitoring_t *inst, const gpioPin_t debugPins[DEBUG_PINS], gpio_t * gpioInst);
void mon_debugGPIO_HIGH(monitoring_t *inst, u8 Pin);
void mon_debugGPIO_LOW(monitoring_t *inst, u8 Pin);
void mon_setLoopDuration(monitoring_t *inst, float duration);
//--ctrlDebug
void mon_ctrlDebugInit(monitoring_t *this);
void mon_ctrlDebugAppend(monitoring_t *this);
void mon_ctrlDebugStartRead(monitoring_t *this);
void mon_ctrlDebugStoptRead(monitoring_t *this);
void mon_ctrlDebugRead(monitoring_t *this);
void mon_ctrlTrigger(monitoring_t *this);

#endif
