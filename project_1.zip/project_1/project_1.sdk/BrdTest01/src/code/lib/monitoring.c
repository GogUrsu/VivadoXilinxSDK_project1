#include "monitoring.h"


void mon_init(monitoring_t *inst){

	//init control loop timer

	//init control

	mon_ctrlDebugInit(inst);
}

void mon_debugGPIO_init(monitoring_t *monInst, const gpioPin_t debugPins[DEBUG_PINS], gpio_t * gpioInst){

	monInst->gpioPtr = gpioInst;

	u8 index = 0;
	for(;index < DEBUG_PINS; index++){
		monInst->DebugPins[index] = debugPins[index];

		XGpioPs_SetDirectionPin(&gpioInst->GPIOPtr, monInst->DebugPins[index].PinId, (u32) monInst->DebugPins[index].PinDirection);
		XGpioPs_SetOutputEnablePin(&gpioInst->GPIOPtr, monInst->DebugPins[index].PinId, 0x1);
	}

}

void mon_debugGPIO_HIGH(monitoring_t *inst, u8 Pin){
	if(inst->gpioPtr != NULL)
	{
		XGpioPs * GPIOptr = &(inst->gpioPtr)->GPIOPtr;
		XGpioPs_WritePin(GPIOptr, inst->DebugPins[Pin].PinId, 0x1);
	}
}

void mon_debugGPIO_LOW(monitoring_t *inst, u8 Pin){
	if(inst->gpioPtr != NULL)
	{
		XGpioPs * GPIOptr = &(inst->gpioPtr)->GPIOPtr;
		XGpioPs_WritePin(GPIOptr, inst->DebugPins[Pin].PinId, 0x0);
	}
}


void mon_setLoopDuration(monitoring_t *this, float duration)
{

	this->LoopDuration = duration;

	/* Eval Control loop Duration */
	//throw warning/error etc.
}

void mon_ctrlDebugInit(monitoring_t *this)
{
	this->ctrlDebug.index = 0;
	this->ctrlDebug.readCounter = 0;
	this->ctrlDebug.maxCount = CTRL_DEBUG_VALUES_COUT;
	this->ctrlDebug.maxVars = CTRL_DEBUG_VALUES_VARS;
	this->ctrlDebug.triggerCounter = 0;
	this->ctrlDebug.trigger = ctrlDebugTrigger_inactive;
}

void mon_ctrlDebugAppend(monitoring_t *this)
{
	if(this->ctrlDebug.state == cntlDebugState_write){
		u16 i = 0;
		u16 index = this->ctrlDebug.index;
		for(;i<this->ctrlDebug.maxVars;i++){
			this->ctrlDebug.ValueArray[i][index] = this->ctrlDebug.appendArray[i];
		}

		this->ctrlDebug.index = (this->ctrlDebug.index + 1) % this->ctrlDebug.maxCount;

		if(this->ctrlDebug.trigger == ctrlDebugTrigger_active){

			if(this->ctrlDebug.triggerCounter < this->ctrlDebug.maxCount){
				this->ctrlDebug.triggerCounter++;
			} else {
				this->ctrlDebug.triggerCounter = 0;
				this->ctrlDebug.trigger = ctrlDebugTrigger_inactive;
				mon_ctrlDebugStartRead(this);
			}

		}
	}
}

void mon_ctrlDebugStartRead(monitoring_t *this)
{
	this->ctrlDebug.state = ctrlDebugState_read;
	this->ctrlDebug.readCurrIndex = this->ctrlDebug.index;
}

void mon_ctrlDebugStoptRead(monitoring_t *this)
{
	this->ctrlDebug.state = cntlDebugState_write;
	this->ctrlDebug.readCounter = 0;
}

void mon_ctrlDebugRead(monitoring_t *this){

	u16 i = 0;
	u16 readIndex  = this->ctrlDebug.readCurrIndex;
	u16 readCounter = this->ctrlDebug.readCounter;

	if(this->ctrlDebug.state == ctrlDebugState_read){
		if(readCounter < this->ctrlDebug.maxCount){
			for(;i<this->ctrlDebug.maxVars;i++){
				this->ctrlDebug.readArray[i] = this->ctrlDebug.ValueArray[i][readIndex];
			}

			this->ctrlDebug.readCounter++;
			this->ctrlDebug.readCurrIndex = (this->ctrlDebug.readCurrIndex + 1) % this->ctrlDebug.maxCount;
		}
		else {
			mon_ctrlDebugStoptRead(this);
		}
	}
}

void mon_ctrlTrigger(monitoring_t *this)
{
	if(this->ctrlDebug.trigger == ctrlDebugTrigger_inactive)
	{
		this->ctrlDebug.trigger = ctrlDebugTrigger_active;
	}
}

