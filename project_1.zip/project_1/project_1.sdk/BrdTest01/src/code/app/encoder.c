/*
 * AIT RISE 2020
 * Ported: Igor Vojnovic
 *
 * */

#include "app/encoder.h"


void encoder_init(encoder_t *this, encoderConf_t encoderConf)
{
	this->ScaleRawToPu = (float)((1.0f)/(encoderConf.quencConf.PulseMax));
	//Init hardware interface
	quenc_init(&this->quenc, encoderConf.quencConf);
}

u16 encoder_getPosition(encoder_t *this)
{
	return quenc_getRaw(&this->quenc);
}

u16 encoder_getOffset(encoder_t *this)
{
	return quenc_getOffset(&this->quenc);
}

void encoder_setPositionRaw(encoder_t *this, u16 rawPosition)
{
	quenc_setCounter(&this->quenc, rawPosition);
}

void encoder_setOffset(encoder_t *this, u16 offset)
{
	quenc_setOfsset(&this->quenc, offset);
}
