/*
 * AIT RISE 2020
 * Author: Igor Vojnovic
 * */

#include "app/canapp.h"
#include "app/app.h"


/* Global variable system -> app.h
 * access motor and system variables */
extern app_t App;

// returns index of id in list if list contains item
// otherwise it returns 255
#define CAN_MAP_NOINDEX 255



//=====================================================
//						RECV
//=====================================================

void canapp_recvCallback(u16 canID, u8 *recvBuffer){

	u8 indexId;

	mon_debugGPIO_HIGH(&App.Monitoring, DebugPin3);
	switch(canID)
	{
		case canID_control:
			App.Can.Watchdog = 0;
			canapp_controlCallback(recvBuffer);
			break;
		case canID_config_rotaryFdb:
			canapp_config_rotaryFdbCallback(recvBuffer);
			break;
		default:
			break;
	}


//	u32 delay;
//	for(; delay < 1000; delay++){};
//	delay = 0;
	mon_debugGPIO_LOW(&App.Monitoring, DebugPin3);
}


//=====================================================
// motor specific recv data
//=====================================================
// directly interpreted and processed
//=====================================================
void canapp_controlCallback(u8* recvBuffer){
	control1_t* msg = (control1_t *) recvBuffer;
	u16 raw;

	if(msg->doAbsEncCali == 1){
		rotaryFdb_calibrateAbsolutInterface(&App.RotaryFdb0);

	}


   // printf("IRQ Start ------------------------------ CanControl1Recv \n\r");
   //for(int delay = 0; delay < 2000000; delay++){};


	//xil_printf("control-start: %d \n\r", msg->controlStart);

   // printf("IRQ Stop ------------------------------ CanControl1Recv \n\r");
}

//=====================================================
// Configuration
//=====================================================
void canapp_config_rotaryFdbCallback(u8* recvBuffer){
	encoder_t * encoder = &App.RotaryFdb0.Encoder;
	config_rotaryFdb_t * rotaryFdbConfig = (config_rotaryFdb_t*) recvBuffer;

	encoder_setOffset(encoder, rotaryFdbConfig->offset);
}

//=====================================================
//						SEND
//=====================================================

void canapp_sendIntrHandler(void * CallBackRef){

	app_t * app = (app_t *) CallBackRef;
	app->CanSend.clearIntr(&app->CanSend);

	//can watchdog only active when motorControl is running


	//mon_debugGPIO_HIGH(&App.Monitoring, DebugPin1);




	//mon_debugGPIO_LOW(&App.Monitoring, DebugPin1);

}






