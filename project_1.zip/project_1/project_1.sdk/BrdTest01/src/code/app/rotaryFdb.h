/*
 * AIT RISE 2020
 * Author: Igor Vojnovic
 * */

#ifndef _ROTARYFDB_H_
#define _ROTARYFDB_H_

#include "app/encoder.h"
#include "app/resolver.h"

// rotaryFdb supports multiple relative or absolute measurement interfaces
//		- AD2S1200 over SPI - Absolute - to slow for control
//		- AD2S1200 over Parallel Bus - Absolute - NOT IMPLEMENTED
//		- Quadrature Encoder - Relative
// Independent of the measurement interface the interface-mode can either be
// absolute or relative. Absolute measurement interfaces set the
// isAbsolute-Flag per default which is needed for interface-mode: absolute.
// In order to use the quadrature encoder in "interface-mode: absolute"
// the absolute position needs to be calibrated via an absolute measurement
// interface. There is a dedicated function provided for this purpose. In
// "interface-mode: relative" the isAbsolute-Flag is ignored, any measurement
// interface can be used.
//
// CAUTION - IMPORTANT:
// The measurement interface "AD2S1200 over SPI" is generally too slow for
// control operation and is only intended as an calibration interface.
// Nothing will stop (no errors or warnings will be issued) the user to use
// it as a default interface, the user is responsible for selecting the right
// interface


// Interface Mode: absolute or relative interface (independent of measuring interface)
typedef enum {
	//relative mode: only relative position is necessary for control
	//				 isAbsolute flag is ignored
	rotarayFdbInterMode_relative,
	//absolute mode: absolute position is necessary for control
	//				 isAbsolute flag needs to be set -> if not error
	rotarayFdbInterMode_absolute
} rotaryFdbInterMode;

// measuring mode -> how is position measured
typedef enum {
	//Uses FPGA AXI encoder module (A,B,I) - relative Interface
	//This interface does not know if a real quadrature encoder is connected
	//or (e.g.) the interface is emulated by AD2S1200
	// - isAbsolute is not set
	rotaryFdbMeasMode_encoder,
	//Uses AD2S1200 serial interface for resolver - absolute Interface
	//This interface is generally to slow for control operation! only use
	//for calibration.
	//isAbsolute is set
	rotaryFdbMeasMode_resolver_serial,
	//Uses AD2S1200 parallel interface for resolver - absolute Interface
	// NOT IMPLEMENTED YET
	//isAbsolute is set
	rotaryFdbMeasMode_resolver_parallel,
} rotaryFdbMeasMode;

// PosSignal -> is mechanical position measured or electrical
typedef enum {
	// specify elPosSignalFactor if resolver pole pair does not match
	// motor pole pair
	rotaryFdbPosSignal_electric,
	rotaryFdbPosSignal_mechanic
} rotaryFdbPosSignal;


// SpeedMode -> how is speed measured/calculated
typedef enum  {
	// calculation based difference + Filtering (MA + PT1)
	rotaryFdbSpeedMode_DMAPT1,
	// measurement based on resolver module
	rotaryFdbSpeedMode_resolver,
	// calculation based on Kalman-filtering - NOT IMPLEMENTED
	rotaryFdbSpeedMode_kalman,
}rotaryFdbSpeedMode;

typedef struct rotaryFdbValues_T {
	u16 	MechRaw;
	float 	MechPu;
	float 	MechRad;
	float 	MechSpeedHz;
	float 	MechSpeedRpm;
	u16		ElRaw;
	float	ElPu;
	float	ElRad;
	float	ElSpeedHz;
} rotaryFdbValues_t;

typedef struct rotaryFdb_T {
	// values
	rotaryFdbValues_t Values;
	// mode
	rotaryFdbInterMode InterMode;
	rotaryFdbMeasMode MeasMode;
	rotaryFdbSpeedMode SpeedMode;
	rotaryFdbPosSignal PosSignal;
	float elPosSignalFactor;
	// position & speed
	resolver_t Resolver;
	encoder_t Encoder;
	// state for absoluteEncoder mode
	u8 isAbsolute : 1;
}rotaryFdb_t;

typedef struct rotaryFdbConf_T{
	rotaryFdbInterMode defaultInterMode;
	rotaryFdbMeasMode defaultMeasMode;
	rotaryFdbSpeedMode defaultSpeedMode;
	rotaryFdbPosSignal defaultPosSignal;
	u16 defaultOffset;
	float elPosSignalFactor;
	encoderConf_t encoderConf;
	resolverConf_t resolverConf;
} rotaryFdbConf_t;

void rotaryFdb_init(rotaryFdb_t* rotaryFdb, rotaryFdbConf_t rotaryFdbConf);
void rotaryFdb_getPosition(rotaryFdb_t* rotaryFdb);
void rotaryFdb_calibrateAbsolutInterface(rotaryFdb_t* rotaryFdb);
void rotaryFdb_getSpeed(rotaryFdb_t* this);

void rotaryFdb_calcPosValues(rotaryFdb_t* this, float ScaleRawToPu, u16 mechRaw);
void rotaryFdb_calcPosValuesFromMechRaw(rotaryFdb_t* this, float ScaleRawToPu, u16 mechRaw);
void rotaryFdb_clacPosValuesFromElRaw(rotaryFdb_t* this, float ScaleRawToPu, u16 elRaw);

void rotaryFdb_calcMechSpeed(rotaryFdb_t* this);

#endif
