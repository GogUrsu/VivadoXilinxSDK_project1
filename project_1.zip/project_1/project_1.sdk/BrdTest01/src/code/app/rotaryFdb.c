/*
 * AIT RISE 2020
 * Author: Igor Vojnovic
 * */

#include "math.h"
#include <stdlib.h>
#include "app/rotaryFdb.h"

#include "app/app.h"
extern app_t App;


void rotaryFdb_init(rotaryFdb_t* this, rotaryFdbConf_t rotaryFdbConf)
{
	// init Values
	this->Values.ElPu = 0;
	this->Values.ElRad = 0;
	this->Values.ElSpeedHz = 0;
	this->Values.MechPu = 0;
	this->Values.MechRad = 0;
	this->Values.MechRaw = 0;
	this->Values.MechSpeedHz = 0;

	// int encoder
	// TODO only INIT if ENCODER is set in the rotaryFdbConf (give possibility to leave blank if hardware is not present)
	encoder_init(&this->Encoder, rotaryFdbConf.encoderConf);
	//set encoder positionMode

	//init resolver
	// TODO only INIT if RESOLVER is set in the rotaryFdbConf (give possibility to leave blank if hardware is not present)
	resolver_init(&this->Resolver, rotaryFdbConf.resolverConf, &App.Gpio);

	encoder_setOffset(&this->Encoder, rotaryFdbConf.defaultOffset);


	//init states of modes
	this->InterMode = rotaryFdbConf.defaultInterMode;
	this->MeasMode =  rotaryFdbConf.defaultMeasMode;
	this->SpeedMode = rotaryFdbConf.defaultSpeedMode;
	this->PosSignal = rotaryFdbConf.defaultPosSignal;
	// -- absoluteEncoder
	this->isAbsolute = 0;
}

void rotaryFdb_getPosition(rotaryFdb_t* this)
{
	u16 raw;
	switch(this->MeasMode){
		case rotaryFdbMeasMode_encoder:
			if(((this->InterMode == rotarayFdbInterMode_absolute) && (this->isAbsolute == 1)) ||
					(this->InterMode == rotarayFdbInterMode_relative)){
				raw = encoder_getPosition(&this->Encoder);
				rotaryFdb_calcPosValues(this, this->Encoder.ScaleRawToPu, raw);
			} else if ((this->isAbsolute == 0) && (this->InterMode == rotarayFdbInterMode_absolute)){
				//app_setError(appError_sensorRotaryError,sensorRotaryError_AbsPosNotSet);
			} else {
				//app_setError(appError_sensorRotaryError,sensorRotaryError_UndefMeasInter); }
			break;
		case rotaryFdbMeasMode_resolver_serial:
			//Absolute Interface
			raw = resolver_getPosition(&this->Resolver);
			rotaryFdb_calcPosValues(this, this->Resolver.ScaleRawToPu, raw);
			this->isAbsolute = 1;
			break;
		case rotaryFdbMeasMode_resolver_parallel:
				//app_setError(appError_sensorRotaryError,sensorRotaryError_UndefMeasInter);
			break;
		default:
			break;
	}
}
}


void rotaryFdb_calibrateAbsolutInterface(rotaryFdb_t* this)
{

	//TODO - CALIBRATION; UNTRACKED FILES -> *.xlsx; Create Errorflags

	u16 raw = 0;
	s16 raw_tmp = 0;
	u16 raw_sum = 0;
	u16 valid_count = 0;
	u16 rawArray[10] = {0,0,0,0,0,0,0,0,0,0};
	u16 raw_diff = 0;
	int i = 0;

	//raw = resolver_getPosition(&this->Resolver);
	//encoder_setPositionRaw(&this->Encoder, raw);
	//rotaryFdb_calcPosValues(this, this->Resolver.ScaleRawToPu, raw);

	//Get the absolute position from resolver chip, make X attempts.
	for(i = 0;i < 10;i++){
		raw_tmp = resolver_getPosition(&this->Resolver);

		if(raw_tmp != -1){
			rawArray[i] = raw_tmp;
			this->isAbsolute = 1;
			raw_sum = raw_sum  + raw_tmp;
			valid_count = valid_count + 1;

		}else{
			// raw_temp value is invalid -> mark entry invalid
			rawArray[i] = 4900;
			this->isAbsolute = 0;
			//app_setError(appError_sensorRotaryError, sensorRotaryError_CaliErrorRotorSpin);
		}
	}

	//time delay between two samples
	raw_diff = (u16)(abs(rawArray[9]) - rawArray[3]);

	//Check if difference changes too much --> if yes motor is probably spinning
	if(raw_diff > 3){
		//app_setError(appError_sensorRotaryError, sensorRotaryError_CaliErrorRotorSpin);
		this->isAbsolute = 0;
		//break;
	}

	//Only use valid raw values
	if(valid_count > 0){
		raw = raw_sum/valid_count;
	}else{
		raw = 0;
	}


	encoder_setPositionRaw(&this->Encoder, raw);
	rotaryFdb_calcPosValues(this, this->Resolver.ScaleRawToPu, raw);


}



// speed returns allways electrical speed in Hz
void rotaryFdb_getSpeed(rotaryFdb_t* this)
{
	switch(this->SpeedMode){

	case rotaryFdbSpeedMode_DMAPT1:
		//DMAPT1_getSpeed(&this->DMAPT1, this->Values.ElPu, &this->Values.ElSpeedHz);
		rotaryFdb_calcMechSpeed(this);
		break;
	case rotaryFdbSpeedMode_resolver:
		// TODO resolver_getSpeed not implemented
		//resolver_getSpeed(&this->Resolver, &this->Values.ElSpeedHz);
		break;
	case rotaryFdbSpeedMode_kalman:
		//TODO SPEEDESTIMATOR
		break;
	default:
		break;
	}
}

void rotaryFdb_calcPosValues(rotaryFdb_t* this, float ScaleRawToPu, u16 raw)
{
	switch (this->PosSignal) {
		case rotaryFdbPosSignal_electric:
			rotaryFdb_clacPosValuesFromElRaw(this, ScaleRawToPu, raw);
			break;
		case rotaryFdbPosSignal_mechanic:
			rotaryFdb_calcPosValuesFromMechRaw(this, ScaleRawToPu, raw);
			break;
		default:
			break;
	}
}

// Raw Values are Mechanical raw position; ElRaw is not calculated
void rotaryFdb_calcPosValuesFromMechRaw(rotaryFdb_t* this, float ScaleRawToPu, u16 mechRaw)
{
	float ElPu;
	this->Values.MechRaw = mechRaw;
	this->Values.MechPu = (float)((float)this->Values.MechRaw * ScaleRawToPu);
	this->Values.MechRad = (float)(this->Values.MechPu * 2.0f * (float)M_PI);
	ElPu = this->Values.MechPu * 1;//App.Motor.Param.PolePair;
	this->Values.ElPu = ElPu - (float)((int) ElPu); // modulo 1
	this->Values.ElRad = this->Values.ElPu * 2.0f * (float)M_PI;
	//
	this->Values.ElRaw = 0;
}

// Raw Values are electrical raw position; mech values not calculated (Raw, PU, Rad) !
void rotaryFdb_clacPosValuesFromElRaw(rotaryFdb_t* this, float ScaleRawToPu, u16 elRaw)
{
	float rotaryFdbPu;
	//TODO Factor to config.c -> elPosSignalFactor
	float factor = 1;
	this->Values.ElRaw = elRaw;
	rotaryFdbPu = (float)((float)this->Values.ElRaw * ScaleRawToPu * factor);
	this->Values.ElPu = rotaryFdbPu - (float)((int) rotaryFdbPu); // modulo 1
	this->Values.ElRad = (float)(this->Values.ElPu * 2.0f * (float)M_PI);
	//
	this->Values.MechRaw = 0;
	this->Values.MechPu = 0;
	this->Values.MechRad = 0;
}

void rotaryFdb_calcMechSpeed(rotaryFdb_t* this)
{
	this->Values.MechSpeedHz = this->Values.ElSpeedHz ;// /App.Motor.Param.PolePair;
	this->Values.MechSpeedRpm = this->Values.MechSpeedHz * 60;
}


