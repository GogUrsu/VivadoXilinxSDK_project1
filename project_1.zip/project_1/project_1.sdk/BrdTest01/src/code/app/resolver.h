/*
 * AIT RISE 2022
 * Author: Igor Vojnovic
 * */


#ifndef _RESOLVER_H_
#define _RESOLVER_H_

#include "hardware/peripheral/gpio.h"
#include "xspips.h"

#define RESOLVER_PIN_COUNT 5
#define SPI_MSG_BYTESIZE 3

typedef struct resolver_T{
	//Error Data
	u8 DOS; //Degradation of signal flag
	u8 LOT; //Loss of tracking flag
	float ScaleRawToPu;
	// SPI & GPIO
	u8 RecvBuffer[SPI_MSG_BYTESIZE];
	u8 SendBuffer[SPI_MSG_BYTESIZE];
	XSpiPs spi;
	gpio_t *gpioPtr;
	gpioPin_t resolverPins[RESOLVER_PIN_COUNT];
} resolver_t;


typedef enum {
	resolverPin_SAMPLE = 0,
	resolverPin_OE0 = 1,
	resolverPin_RESET = 2,
	resolverPin_MOSI = 3,
	resolverPin_RDVEL = 4
} resolverPin;

typedef struct resolverConf_T{
	gpioPin_t resolverPins[RESOLVER_PIN_COUNT];
	u8 XSpiPs_DeviceID;
	u32 XSpiPs_Options;
	u8 XSpiPs_Prescaler;
	u8 XSpiPs_CSId;
} resolverConf_t;

u8 resolver_init(resolver_t* this, resolverConf_t encoderConf, gpio_t * gpioInst);
s16 resolver_getPosition(resolver_t* this);
void resolver_getSpeed(resolver_t *this, float * SpeedHz);

#endif
