/*
 * AIT RISE 2020
 * Author: Igor Vojnovic
 * */


#ifndef _ENCODER_H_
#define _ENCODER_H_

#include "hardware/drivers/quenc.h"


typedef struct encoder_T{
	quenc_t quenc;
	// position
	float	ScaleRawToPu;
} encoder_t;


typedef struct encoderConf_T{
	quencConf_t quencConf;
} encoderConf_t;

u16 encoder_getPosition(encoder_t *this);
void encoder_init(encoder_t* this, encoderConf_t encoderConf);
void encoder_setPositionRaw(encoder_t *this, u16 rawPosition);
void encoder_setOffset(encoder_t *this, u16 offset);
u16 encoder_getOffset(encoder_t *this);

#endif
