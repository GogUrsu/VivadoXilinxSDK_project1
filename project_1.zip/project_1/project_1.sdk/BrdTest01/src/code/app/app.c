/*
 * AIT RISE 2020
 * Author: Igor Vojnovic
 * */

#include "app/app.h"
#include "app/rotaryFdb.h"

int app_init(appConf_t appConf)
{

	//configure App
	App.FPGAClk = appConf.FPGAClk;

	//configure rotaryFeedback
	rotaryFdb_init(&App.RotaryFdb0,appConf.rotaryFdbConf0);

	return XST_SUCCESS;
}

//===============================================================
// ADCIntrHandler()
//===============================================================
// Called after PWM Modules triggers ADC Conversion and all
//===============================================================
void app_ADCIntrHandler(void * CallBackRef)
{

}

//===============================================================
// controlIntr()
//===============================================================
//  provides all the necessary input values for the control
//  performs all needed calibration for selected controller
//		- selects control loop
//		- calibration of sensors
//			-> ADC Zero Value, Encoder Zero Offset
//		- reads all sensor values
//			-> ADC, Encoder etc.
//		- carries out necessary calculations
//			-> COS Transform/Observer etc.
//===============================================================
// remarks:
// select desired controller here -> FOC-ASM/FOC-PSM/etc.
// usually located in separate .h/.c files
//===============================================================
void app_controlIntr()
{


}


void app_schedularTask(void * CallBackRef)
{
	app_t * app = (app_t *) CallBackRef;
	app->Schedular.clearIntr(&app->Schedular);
//	mon_debugGPIO_HIGH(&App.Monitoring, DebugPin2);
//	mon_debugGPIO_LOW(&App.Monitoring, DebugPin2);
	rotaryFdb_getPosition(&app->RotaryFdb0);

}







// Implement Logging, eMMC/MMC ... etc.
void app_dolog( XTime execT, char* file, int line ,const char *format, ...)
{
	//TODO Logging

}





