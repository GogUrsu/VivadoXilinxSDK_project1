/*
 * AIT RISE 2020
 * Author: Igor Vojnovic
 * */

#ifndef _CANAPP_H_
#define _CANAPP_H_

#include "hardware/peripheral/can.h"

/*
 * Each CAN MSG has -> an ID see enum canID
 * 					-> its own struct as datacontainer
 * 				    -> function for send/recv messages
 *
 * Receiving messages is handled by canappRecv. (see can.h)
 * An switch instruction handles the assignment between
 * canID and recv-function callback.
 *
 * Sending messages is done by calling the corresponding
 * send-function.
 *
 * To Edit the can Messages:
 * 			(1) update canID-enum
 * 			(2) create struct as datacontainer
 * 			(3) create send/recv function
 * 			(4a) recv -> edit canappRecv
 * 			 (b) send -> call function
 *
 * */

typedef enum  { // UPDATE => CAN DB ACCORDINGLY
	/* SEND  */
	canID_appInfo			= 0x0C8, /* 200 */
	canID_errorApp1		    = 0xFA,	 /* 250	*/
	canID_errorApp2			= 0xFB,	 /* 251	*/
	canID_errorMotor1		= 0xFC,	 /* 252	*/
	canID_errorMotor2		= 0xFD,	 /* 253	*/
	canID_sensCurrent1 		= 0x12D, /* 301 */
	canID_sensCurrent2 		= 0x12E, /* 302 */
	canID_sensCurrentLimit1	= 0x12F, /* 303 */
	canID_sensCurrentLimit2	= 0x130, /* 304 */
	canID_sensDCVolt		= 0x131, /* 305 */
	canID_sensDCVoltLimit	= 0x132, /* 306 */
	canID_rotaryFdb1		= 0x136, /* 310 */
	canID_rotaryFdb2		= 0x137, /* 311 */
	canID_rotaryFdb3		= 0x138, /* 312 */
	canID_Temp1				= 0x15F, /* 351 */
	canID_Temp2				= 0x160, /* 352 */
	canID_Temp3				= 0x161, /* 353 */
	canID_Temp4				= 0x162, /* 354 */
	canID_Temp5				= 0x163, /* 355 */
	canID_Temp6				= 0x164, /* 356 */

	canID_debug01			= 0x190, /* 400 */
	canID_debug02			= 0x191, /* 401 */
	//debug
	canID_ctrlDebug1        = 0x1F4, /* 500 */
	canID_ctrlDebug2        = 0x1F5, /* 501 */
	canID_ctrlDebug3        = 0x1F6, /* 502 */
	canID_ctrlDebug4        = 0x1F7, /* 503 */
	canID_ctrlDebug5        = 0x1F8, /* 504 */
	canID_ctrlDebug6        = 0x1F9, /* 505 */
	canID_ctrlDebug7        = 0x1FA, /* 505 */

	//
	// -- Controller specific values
	//
	canID_controlOutput00 	= 0x064, /* 100 */
	canID_controlOutput01 	= 0x065, /* 101 */
	canID_controlOutput02 	= 0x066, /* 102 */
	canID_controlOutput03 	= 0x067, /* 103 */
	canID_controlOutput10	= 0x068, /* 104 */
	canID_controlOutput11 	= 0x069, /* 105 */
	canID_controlOutput12 	= 0x06A, /* 106 */
	canID_controlOutput13 	= 0x06B, /* 107 */
	canID_controlOutput20 	= 0x06C, /* 108 */
	canID_controlOutput21 	= 0x06D, /* 109 */
	canID_controlOutput22 	= 0x06E, /* 110 */
	canID_controlOutput23 	= 0x06F, /* 111 */
	canID_controlOutput30 	= 0x070, /* 111 */
	canID_controlOutput31 	= 0x071, /* 112 */
	canID_controlOutput32 	= 0x072, /* 113 */
	canID_controlOutput33 	= 0x073, /* 114 */

	/* RECEIVE */
	//-- Controller-Data
	canID_control 			= 0x31,	/* 49 */

	// --
	// -- Controller specific values
	//
	canID_controlInput00 	= 0x32,	/* 50 */
	canID_controlInput01 	= 0x33,	/* 51 */
	canID_controlInput02 	= 0x34,	/* 52 */
	canID_controlInput03 	= 0x35,	/* 53 */
	canID_controlInput10 	= 0x36,	/* 54 */
	canID_controlInput11 	= 0x37,	/* 55 */
	canID_controlInput12 	= 0x38,	/* 56 */
	canID_controlInput13 	= 0x39,	/* 57 */
	// -- Controller parameter
	canID_controlParam00	= 0x50, /* 80 */
	canID_controlParam01	= 0x51, /* 81 */
	canID_controlParam02	= 0x52, /* 82 */
	canID_controlParam03	= 0x53, /* 83 */
	canID_controlParam10	= 0x54, /* 84 */
	canID_controlParam11	= 0x55, /* 85 */
	canID_controlParam12	= 0x56, /* 86 */
	canID_controlParam13	= 0x57, /* 87 */
	canID_controlParam20	= 0x58, /* 88 */
	canID_controlParam21	= 0x59, /* 89 */
	canID_controlParam22	= 0x5A, /* 90 */
	canID_controlParam23	= 0x5B, /* 91 */
	canID_controlParam30	= 0x5C, /* 92 */
	canID_controlParam31	= 0x5D, /* 93 */
	canID_controlParam32	= 0x5E, /* 94 */
	canID_controlParam33	= 0x5F, /* 95 */

	// -- Configuration-Data
	canID_config_rotaryFdb	= 0x3E8, /* 1000 */

}canID;


//===============================================================
// 		CAN MESSAGES
//===============================================================
//======== SEND =================================================
typedef struct phaseCurrent1_T{

	float iU_ist;
	float iV_ist;

} phaseCurrent1_t;

typedef struct phaseCurrent2_T{

	float iW_ist;
	float iDC_ist;

} phaseCurrent2_t;

typedef struct phaseCurrent1_RAW_T{

	u16 iU_ist;
	u16 iV_ist;
	u16 iW_ist;
	u16 Y;

} phaseCurrent1_RAW_t;


typedef struct currentLimit_T {
	u8 PhaseU_LimitStatus;
	u8 PhaseU_BandCounter;
	u8 PhaseV_LimitStatus;
	u8 PhaseV_BandCounter;
	u8 PhaseW_LimitStatus;
	u8 PhaseW_BandCounter;
	u8 BandCounterMax;
	u8 BandBehaviour:4;
	u8 unused:4;
}currentLimit_t;


typedef struct debug01_T {

	u8		StateU;
	u8		StateV;
	u8		StateW;
	u8		X;
	float 	CaliVlaue;

}debug01_t;

typedef struct debug02_T {

	float	LoopDuration;
	u16		X;
	u16		EncoderVal;

}debug02_t;

typedef struct appInfo1_T{

	u8 motorState		:1;
	u8 ActiveController	:5;
	u8 ControllerState	:2;
	u8 Error			:1;
	u8 unused			:7;
	u16 unused2;
	u32 unused3;

} appInfo1_t;

typedef struct rotrayFdb1_T {
	float 	ElRad;
	float 	ElPu;
}rotrayFdb1_t;

typedef struct {
	u64 MSG1;
	u64 MSG2;
} ErrorContainer;

typedef struct rotrayFdb2_T {
	float	SpeedMechRPM;
	float	SpeedMechHz;
}rotrayFdb2_t;

typedef struct rotrayFdb3_T {
	u16		EncoderRaw;
	u16		EncoderOffset;
	u32 	unused1;
}rotrayFdb3_t;


typedef struct sens1 {
	float 	sensVal1;
	u16 	sensVal1raw;
	u16		unsused;
}sensVal1_t;


//======== RECV =================================================

typedef struct control1_T {
	u8		controlStart : 1;
	u8		activeController :5;
	u8		resetErrorFlags:1;
	u8		setRotaryFdb:	1;
	u8		startCtrlDebugRead:	1;
	u8		ResetDriverError:	1;
	//--old
	//u16		unused1:	6;
	//--new
	u8		doAbsEncCali: 1;
	u8		unused1:	5;
	//--newEnd
	float   soll;
	u16		unused2;
}control1_t;

typedef struct config_rotaryFdb_T{
	u16 offset;
	u16 unused1;
	u32 unused2;
}config_rotaryFdb_t;


//===============================================================
// 		CAN Functions
//===============================================================
//======== RECV =================================================
void canapp_recvCallback(u16 canID, u8* recvBuffer);
void canapp_controlCallback(u8* recvBuffer);
//-- Config
void canapp_config_rotaryFdbCallback(u8* recvBuffer);

//======== SEND =================================================
void canapp_sendIntrHandler(void * CallBackRef);
void canapp_sendControllerOutput(can_t *canInst);
void canapp_sendPhaseCurrent(can_t *canInst);
void canapp_sendDebug(can_t *canInst);
void canapp_sendAppInfo1(can_t *canInst);
void canapp_sendRotrayFdb(can_t *canInst);
void cannap_sendCurrentLimit(can_t *canInst);
void canapp_sendCtrlDebug(can_t *canInst);
void canapp_sendSens(can_t *canInst);
void canapp_sendTemp(can_t *canInst);
void canapp_sendErrors(can_t *canInst);
void canapp_sendDCVolt(can_t *canInst);

#endif
