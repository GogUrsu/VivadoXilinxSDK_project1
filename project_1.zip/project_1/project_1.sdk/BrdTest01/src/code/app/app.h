/*
 * AIT RISE 2020
 * Author: Igor Vojnovic
 * */

#ifndef _APP_H_
#define _APP_H_


#include "hardware/peripheral/gic.h"
#include "hardware/peripheral/can.h"
#include "hardware/peripheral/gpio.h"
#include "lib/monitoring.h"
#include "xtime_l.h"
#include "rotaryFdb.h"


typedef struct app_T {
	u32					FPGAClk;
	gic_t  				GicInst;
	can_t 				Can;
	monitoring_t 		Monitoring;
	sTimer_t			Schedular;
	sTimer_t			CanSend;
	gpio_t				Gpio;
	rotaryFdb_t			RotaryFdb0;
	rotaryFdb_t			RotaryFdb1;
}app_t;

typedef struct appConf_T {
	u32 FPGAClk;
	rotaryFdbConf_t rotaryFdbConf0;
	rotaryFdbConf_t rotaryFdbConf1;

}appConf_t;

app_t App;


int app_init(appConf_t appConf);

void app_ADCIntrHandler(void * CallBackRef);
void app_controlIntr();
void app_sensIntr();

void app_schedularTask(void * CallBackRef);

u16 app_checkErrors();
void app_resetErrorFlags();

#define LOG(...) app_dolog( 0 /* TIME */, __FILE__, __LINE__, __VA_ARGS__)
void app_dolog(XTime execT, char* file, int line ,const char *format, ...);



#endif
