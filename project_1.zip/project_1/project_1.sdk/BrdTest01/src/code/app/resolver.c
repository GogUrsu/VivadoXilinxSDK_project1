/*
 * AIT RISE 2020
 * Author: Igor Vojnovic
 * */

#include "app/resolver.h"


inline void resolver_PinResetHigh(resolver_t *this);
inline void resolver_PinResetLow(resolver_t *this);
inline void resolver_PinSampleHigh(resolver_t *this);
inline void resolver_PinSampleLow(resolver_t *this);
inline void resolver_PinOE0High(resolver_t *this);
inline void resolver_PinOE0Low(resolver_t *this);
inline void resolver_PinRDVELHigh(resolver_t *this);
inline void resolver_PinRDVELLow(resolver_t *this);
inline void resolver_PinMOSIHigh(resolver_t *this);
inline void resolver_PinMOSILow(resolver_t *this);


//Settings:
//clock polarity = 0 (CPOL = 0)
//clock phase = 1 (CPHA = 1)
u8 resolver_init(resolver_t *this, resolverConf_t resolverConf, gpio_t *gpioInst)
{

	s32 status;
	XSpiPs_Config *spiConfig;

	// init gpio pins
	this->gpioPtr = gpioInst;

	u8 index = 0;
	for(;index < RESOLVER_PIN_COUNT;index++){

		this->resolverPins[index] = resolverConf.resolverPins[index];
		XGpioPs_SetDirectionPin(&gpioInst->GPIOPtr, this->resolverPins[index].PinId, (u32) this->resolverPins[index].PinDirection);
		XGpioPs_SetOutputEnablePin(&gpioInst->GPIOPtr, this->resolverPins[index].PinId, 0x1);//TODO: set to zero
	}

	//init gpio
	spiConfig = XSpiPs_LookupConfig(resolverConf.XSpiPs_DeviceID);
	if (NULL == spiConfig){
		return XST_FAILURE;
	} else status = XST_SUCCESS;

	status = XSpiPs_CfgInitialize(&this->spi, spiConfig, spiConfig->BaseAddress);
	if (status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	status = XSpiPs_SetOptions(&this->spi, resolverConf.XSpiPs_Options);
	if (status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	status = XSpiPs_SetClkPrescaler(&this->spi, resolverConf.XSpiPs_Prescaler);
	if (status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	status = XSpiPs_SetSlaveSelect(&this->spi, resolverConf.XSpiPs_CSId);
	if (status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	status = XSpiPs_SetDelays(&this->spi, 0, 0, 0, 0);
	if (status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	//init Buffer
	memset(this->RecvBuffer, 0x00, sizeof(this->RecvBuffer));
	memset(this->SendBuffer, 0x00, sizeof(this->SendBuffer));

	this->SendBuffer[0] = 192;
	this->SendBuffer[1] = 0;
	this->SendBuffer[2] = 0;

	//scale factor -> 12Bit
	this->ScaleRawToPu = (float)((1.0f)/(4096));

	//init variables
	this->DOS = 0;
	this->LOT = 0;

	// Enable Peripheral
	XSpiPs_Enable(&this->spi);

	// Enable OE0 high
	resolver_PinOE0High(this);

	// AD2S1200 Reset is active low - set to high
	resolver_PinResetHigh(this);

	//RDVEL high = read only position
	resolver_PinRDVELHigh(this);

	//TODO: remove this line MOSI is controlled by SPI hardware
	resolver_PinMOSIHigh(this);

	return status;
}

s16 resolver_getPosition(resolver_t *this)
{
	s16 raw = 0;
	u16 i = 0;
	u8 par_bit_rec = 0;
	s16 raw_tmp = 0;
	u16 par_bit_calc = 0;

	u8 LOT = 0;
	u8 DOS = 0;
	//get data from spi

	resolver_PinSampleLow(this);
	// Delay from Sample to CS
	//Min 6 x tclk
	while(i<200) i++;
	i = 0;

	//toggle MOSI -> Start of MISO on falling edge of MOSI

	//while(i<10) i++;
	//i = 0;
	resolver_PinMOSILow(this);//RD TODO: remove this line MOSI is controlled by SPI hardware

	XSpiPs_PolledTransfer(&this->spi, this->SendBuffer, this->RecvBuffer, SPI_MSG_BYTESIZE);

	resolver_PinMOSIHigh(this); //TODO: remove this line MOSI is controlled by SPI hardware

	resolver_PinSampleHigh(this);
	//process data
	//Packet structure: 1+2 bit ignored 3 bit:MSB ... 14 bit: LSB 15 bit:RDVEL 16 bit: DOS 17 bit: LOT 18bit: PARITY
	//raw = ((this->RecvBuffer[0] << 8 | this->RecvBuffer[1])) >> 4;
	raw = ((this->RecvBuffer[0] << 8 | this->RecvBuffer[1])) >> 2;

	//Check odd parity bit and LOT and DOS

	raw_tmp = raw;
	//Set received parity bit
	par_bit_rec = (u8)(this->RecvBuffer[2]) & 64;

	//Calculate odd parity of the raw spi value
	raw_tmp ^= raw_tmp >> 16;
	raw_tmp ^= raw_tmp >> 8;
	raw_tmp ^= raw_tmp>> 4;
	raw_tmp ^= raw_tmp >> 2;
	raw_tmp^= raw_tmp >> 1;
	par_bit_calc = (u8)(raw_tmp) & 1;

	DOS = (this->RecvBuffer[1]) & 0x1;//
	LOT = (this->RecvBuffer[2] >> 7) & 0x1;//

	//if((par_bit_calc != par_bit_rec) || (LOT != 1) || (DOS != 1)){
	if((LOT != 1) || (DOS != 1)){
		return -1;
	}else{
		//return calculated Values
		return raw;
	}

}


void resolver_getSpeed(resolver_t *this, float * SpeedHz)
{

}

// resolverPin_SAMPLE

void resolver_PinSampleHigh(resolver_t *this)
{
	XGpioPs * GPIOptr = &(this->gpioPtr)->GPIOPtr;
	XGpioPs_WritePin(GPIOptr, this->resolverPins[resolverPin_SAMPLE].PinId, 0x1);
}

void resolver_PinSampleLow(resolver_t *this)
{
	XGpioPs * GPIOptr = &(this->gpioPtr)->GPIOPtr;
	XGpioPs_WritePin(GPIOptr, this->resolverPins[resolverPin_SAMPLE].PinId, 0x0);
}

// Level shifter OE0

void resolver_PinOE0High(resolver_t *this)
{
	XGpioPs * GPIOptr = &(this->gpioPtr)->GPIOPtr;
	XGpioPs_WritePin(GPIOptr, this->resolverPins[resolverPin_OE0].PinId, 0x1);
}

void resolver_PinOE0Low(resolver_t *this)
{
	 XGpioPs * GPIOptr = &(this->gpioPtr)->GPIOPtr;
	XGpioPs_WritePin(GPIOptr, this->resolverPins[resolverPin_OE0].PinId, 0x0);
}

// RDVEL

void resolver_PinRDVELHigh(resolver_t *this)
{
	XGpioPs * GPIOptr = &(this->gpioPtr)->GPIOPtr;
	XGpioPs_WritePin(GPIOptr, this->resolverPins[resolverPin_RDVEL].PinId, 0x1);
}

void resolver_PinRDVELLow(resolver_t *this)
{
	 XGpioPs * GPIOptr = &(this->gpioPtr)->GPIOPtr;
	XGpioPs_WritePin(GPIOptr, this->resolverPins[resolverPin_RDVEL].PinId, 0x0);
}

// resolverPin_RESET

void resolver_PinResetHigh(resolver_t *this){
	XGpioPs * GPIOptr = &(this->gpioPtr)->GPIOPtr;
	XGpioPs_WritePin(GPIOptr, this->resolverPins[resolverPin_RESET].PinId, 0x1);
}

void resolver_PinResetLow(resolver_t *this){
	XGpioPs * GPIOptr = &(this->gpioPtr)->GPIOPtr;
	XGpioPs_WritePin(GPIOptr, this->resolverPins[resolverPin_RESET].PinId, 0x0);
}

// resolverPin_MOSI (RD)

void resolver_PinMOSIHigh(resolver_t *this){
	XGpioPs * GPIOptr = &(this->gpioPtr)->GPIOPtr;
	XGpioPs_WritePin(GPIOptr, this->resolverPins[resolverPin_MOSI].PinId, 0x1);
}

void resolver_PinMOSILow(resolver_t *this){
	XGpioPs * GPIOptr = &(this->gpioPtr)->GPIOPtr;
	XGpioPs_WritePin(GPIOptr, this->resolverPins[resolverPin_MOSI].PinId, 0x0);
}

