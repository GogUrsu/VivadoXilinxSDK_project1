/*
 * AIT RISE 2020
 * Author: Igor Vojnovic
 * */


#include <stdio.h>
#include "xil_printf.h"
#include "xparameters.h"

#include "app/app.h"
#include "app/canapp.h"


#define printf xil_printf
// ADCIntrHandler -> controlLoop.h
extern void app_ADCIntrHandler(void * CallBackRef);
// canapp_recvCallback -> canapp.h
extern void canapp_recvCallback(u16 canID, u8 *recvBuffer);
// CanSendIntrHandler -> canapp.h
extern void canapp_sendIntrHandler(void * CallBackRef);

void schedularTask(void * CallBackRef);

#define PRINT_FLOAT(f)( (f<0) ? printf("-%d.%d\n", (-1)*(int)f, (-1)*(int)(((f-((int)f))*10000))) : printf("%d.%d\n", (int)f,(int)(((f-((int)f))*10000))))


extern const appConf_t appConf;
extern const canConf_t canConf;
extern const pTimerConf_t loopTimer_pTimerConf;
extern const sTimerConf_t scheduler_sTimerConf;
extern const sTimerConf_t canSend_sTimerConf;
extern const gpioEMIOConf_t gpioEMIOConf;
extern const gpioPin_t debugGPIOConf[DEBUG_PINS];
extern u16 IRQListLen;
extern u32 IRQList[];

void do_init(){

	init_platform();

	//===============================================================
	// init Monitoring
	//===============================================================
	mon_init(&App.Monitoring);

	//===============================================================
	// init GPIO
	//===============================================================
	gpio_EMIO_init(&App.Gpio, gpioEMIOConf);

	//===============================================================
	// init GIC
	//===============================================================
	gic_init(&App.GicInst, &IRQList[0] , IRQListLen);

	//===============================================================
	// init CAN
	//===============================================================
	can_init(&App.Can, &App.GicInst, canConf, &canapp_recvCallback);
	// TODO gic_addHandler outside can_init
	//	gic_addHandler is inside can_init
	//  all other gic_addHandler are assigned outside xxx_init
	//  change for better readability and consistency

	//===============================================================
	// Connect InterruptControler to Handler
	// Interrupt Source is ADC Middleware
	// ADC Middlware Handler distinguishes between FOC/SENS Intr
	//===============================================================
	gic_addHandler(&App.GicInst,
		   1,
		   1,
		   1,
		   (Xil_ExceptionHandler)app_ADCIntrHandler, // <-- FIQ INTERRUPT
		   &App);

	//===============================================================
	// init Monitoring and Control Loop Timer
	//===============================================================
	App.Monitoring.LoopDuration = 0;
	pTimer_init(&App.Monitoring.LoopTimer, loopTimer_pTimerConf);
	pTimer_start(&App.Monitoring.LoopTimer);

	//sleep();

	//===============================================================
	// init Task Scheduler
	//===============================================================
	sTimer_init(&App.Schedular,scheduler_sTimerConf);


	//HERE!!!!!!!!!
	gic_addHandler(&App.GicInst,
		   scheduler_sTimerConf.IntrId,
		   scheduler_sTimerConf.IntrPrio,
		   scheduler_sTimerConf.IntrTrigger,
		   (Xil_ExceptionHandler)app_schedularTask,
		   &App);

	sTimer_enableInvervalIntr(&App.Schedular);

	//===============================================================
	// init Can Send Task
	//===============================================================
	sTimer_init(&App.CanSend,canSend_sTimerConf);

	gic_addHandler(&App.GicInst,
		   canSend_sTimerConf.IntrId,
		   canSend_sTimerConf.IntrPrio,
		   canSend_sTimerConf.IntrTrigger,
		   (Xil_ExceptionHandler)canapp_sendIntrHandler,
		   &App);

	sTimer_enableInvervalIntr(&App.CanSend);

	//===============================================================
	// init App
	//===============================================================
	app_init(appConf);

	//===============================================================
	// init GPIO Debugging
	//===============================================================
	mon_debugGPIO_init(&App.Monitoring, debugGPIOConf, &App.Gpio);

}


// Make sure to call Xil_AssertSetCallback
static void AssertPrint(const char8 *file, s32 line) {
	xil_printf("\r\nAssertion in file %s on line %d\r\n", file, line);
}

void ExceptionHandler(void *data) {
	xil_printf("\r\nException %d\r\nHalting\r\n", data);
	_Exit(0);
}


int main()
{
	Xil_AssertSetCallback((Xil_AssertCallback) AssertPrint);

	Xil_ExceptionRegisterHandler(XIL_EXCEPTION_ID_DATA_ABORT_INT,
			ExceptionHandler, (void *) XIL_EXCEPTION_ID_DATA_ABORT_INT);

	do_init();
	/*
	 * Toogle Testpins
	 * */
	u32 delay = 0;
	mon_debugGPIO_HIGH(&App.Monitoring, DebugPin0);
	for(; delay < 500; delay++){};
	mon_debugGPIO_LOW(&App.Monitoring, DebugPin0);
	delay = 0;

	mon_debugGPIO_HIGH(&App.Monitoring, DebugPin1);
	for(; delay < 500; delay++){};
	mon_debugGPIO_LOW(&App.Monitoring, DebugPin1);
	delay = 0;

	mon_debugGPIO_HIGH(&App.Monitoring, DebugPin2);
	for(; delay < 500; delay++){};
	mon_debugGPIO_LOW(&App.Monitoring, DebugPin2);
	delay = 0;

	mon_debugGPIO_HIGH(&App.Monitoring, DebugPin3);
	for(; delay < 500; delay++){};
	mon_debugGPIO_LOW(&App.Monitoring, DebugPin3);
	delay = 0;

/*
*/

	//wait for 20ms
	//pTimer_start(&App.Monitoring.LoopTimer);
	//for(delay = 0; delay < 500000; delay++){};
	//mon_setLoopDuration(&App.Monitoring,pTimer_stop(&App.Monitoring.LoopTimer));
	//rotaryFdb_calibrateAbsolutInterface(&App.Motor.RotaryFdb);

	//TODO Start Application
	//move to app.c
	//===============================================================
	// Start App
	//===============================================================
	//start ttc
	sTimer_start(&App.CanSend);
	sTimer_start(&App.Schedular);


	while(1){
		for(delay = 0; delay < 500000; delay++){};
		xil_printf("RISE!!!!1 ... \n\r");
		delay = 0;
	}
    cleanup_platform();
    return 0;
}

