#ifndef _CONFIGURATION_
#define _CONFIGURATION_

#include "hardware/drivers/quenc.h"
#include "hardware/peripheral/can.h"
#include "hardware/peripheral/timer.h"
#include "hardware/peripheral/gpio.h"
#include "lib/monitoring.h"
#include "app/app.h"
#include "xparameters.h"

// FPGA_CLK_FREQ_HZ -> configuration.h
#define PHASECURRENT_ZEROCALI_TIME 	5000							//in sampling ticks
#define SWITCHING_FREQ_Hz			14000
#define SAMPLING_FREQ_HZ			SWITCHING_FREQ_Hz * 2			//sampling frequency for control loop


#define FS_TO_TS(x) ((float)(1.0f/x))

#define FPGA_CLK_FREQ_HZ	50000000


//TODO Change structure of Intr Config; make single structure for interrupt config, not spread across all timer configs
//===============================================================
// Interrupt Configuration - IRQ List
// By Default, all interrupts are FIQ, all interrupts except one
// need to be assigned to IRQ, include in list:
//===============================================================
u16 IRQListLen = 3;
u32 IRQList[] = {
		XPS_CAN0_INT_ID,
		XPAR_XTTCPS_4_INTR,
		XPAR_XTTCPS_5_INTR
};

//===============================================================
// Motor configuration data
//===============================================================
const appConf_t appConf = {
		.FPGAClk = FPGA_CLK_FREQ_HZ,
		.rotaryFdbConf0 = {
				.defaultInterMode = rotarayFdbInterMode_absolute,
				.defaultMeasMode = rotaryFdbMeasMode_encoder,
				.defaultSpeedMode = rotaryFdbSpeedMode_DMAPT1,
				.defaultPosSignal = rotaryFdbPosSignal_electric,
				.defaultOffset = 2007,//TODO //135,//139,
				// quadrature encoder configuration
				//TODO enciderCONF and resolverCONF should be inside rotaryFDBCONF
				.elPosSignalFactor = 1,
				.encoderConf = {
						// hardware configuration
						.quencConf = {
							.BaseAddr 	= 1,//XPAR_QUENC_V2_0_0_BASEADDR,
							// 4096 for AD2S1200
							.PulseMax 	= 4096,
							.Offset 	= 0, // TODO redudant info, rotorayFDB also has offset
							.IndexCfg 	= indexCfg_I_Rising,//indexCfg_TopValue,//indexCfg_I_Rising,
							.InvertBit 	= 0
							},
				},
				.resolverConf = {
						//SPI Configuration for AD2S1200
						.XSpiPs_DeviceID = (u8)1,//XPAR_XSPIPS_1_DEVICE_ID, !!!!!!!
						.XSpiPs_Options = (XSPIPS_MANUAL_START_OPTION | // Polled  Operation
										  XSPIPS_MASTER_OPTION 		  |	// RISE is Master
										  XSPIPS_FORCE_SSELECT_OPTION | //
										  XSPIPS_CLK_PHASE_1_OPTION    // CPHA = 1
										  //XSPIPS_CLK_ACTIVE_LOW_OPTION  // CPOL = 1 should be CPOL = 0
										  ),
						.XSpiPs_Prescaler = XSPIPS_CLK_PRESCALE_256,    //680 kHz Clk
						.XSpiPs_CSId = 0U,
						.resolverPins = {
								{		//resolverPin_SAMPLE
										.PinId = (u8)59,
										.PinDirection = gpioDirection_Out
								},
								{		//OE0
										.PinId = (u8)67,
										.PinDirection = gpioDirection_Out
								},
								{		//resolverPin_RESET
										.PinId = (u8)62,
										.PinDirection = gpioDirection_Out
								},
								{		//MOSI
										.PinId = (u8)63,
										.PinDirection = gpioDirection_Out
								},
								{		//RDVEL
										.PinId = (u8)64,
										.PinDirection = gpioDirection_Out
								}
						}
				},
		},
};





//===============================================================
// CAN configuration data
//===============================================================
// Contains data for the hardware configuration of CAN, to edit
// CAN Messages etc. modify canapp.h/.c directly
//===============================================================
const canConf_t canConf = {
		.canDeviceId 		= (u8) XPAR_XCANPS_0_DEVICE_ID,
		.baudRatePrescaler 	= (u8) 9, // 49 -> 100kbps, 9 -> 500kbps
		 // TODO ATTENTION NEEDED!!!!!!!
		 //Timing parameters to be set in the Bit Timing Register (BTR).
		 //These values are for a 40 Kbps baudrate assuming the CAN input
		 //clock frequency is 24 MHz.
		.syncJumpWidth		= (u8) 3,
		.firstTimingSegment = (u8) 15,
		.secondTimingSegment= (u8) 2,
		//CAN0: XPS_CAN0_INT_ID = 60
		//CAN1: XPS_CAN1_INT_ID = 83
		.intrId				= (u32) XPS_CAN0_INT_ID,
		.IntrPrio			= (u8) 0xA2,
		.IntrTrigger		= (u8) 0x03
};

//===============================================================
// Loop timer (pTimer) configuration data
//===============================================================
const pTimerConf_t loopTimer_pTimerConf = {
		.pTimerDeviceId 	= (u8) XPAR_PS7_SCUTIMER_0_DEVICE_ID,
		/* use max value */
		.loadValue			= (u32) 0xFFFFFFFF
};

//===============================================================
// Scheduler Timer (sTimer) configuration data
//===============================================================
const sTimerConf_t scheduler_sTimerConf = {
		.DeviceID 		= (u16) XPAR_PS7_TTC_4_DEVICE_ID,
		.IntrId 		= (u32) XPAR_XTTCPS_4_INTR,
		.IntrPrio		= (u8) 0xA0,
		.IntrTrigger	= (u8) 0x03,
		// Output Frequency in [Hz]
		.OutputHz 		= (u32) 20,
		// leave zero, configured/used later
		.Interval 		= 0,
		.Prescaler 		= 0,
		// timer Options
		.Options 		= (XTTCPS_OPTION_INTERVAL_MODE |
							XTTCPS_OPTION_WAVE_DISABLE)
};

//===============================================================
// Can Send Timer (sTimer) configuration data
//===============================================================
const sTimerConf_t canSend_sTimerConf = {
		.DeviceID 		= (u16) XPAR_PS7_TTC_5_DEVICE_ID,
		.IntrId 		= (u16) XPAR_XTTCPS_5_INTR,
		.IntrPrio		= (u8) 0xA1,
		.IntrTrigger	= (u8) 0x03,
		// Output Frequency in [Hz]
		.OutputHz 		= (u32) 50,
		// leave zero, configured/used later
		.Interval 		= 0,
		.Prescaler 		= 0,
		// timer Options
		.Options 		= (XTTCPS_OPTION_INTERVAL_MODE |
							XTTCPS_OPTION_WAVE_DISABLE)
};


//===============================================================
// GPIO EMIO Configuration Data
//===============================================================
const gpioEMIOConf_t gpioEMIOConf = {
		.GPIODeviceID = (u8) XPAR_PS7_GPIO_0_DEVICE_ID
		//.GPIODeviceID = (u8) 0
};

//===============================================================
// DEBUG GPIO
//===============================================================
// IMPORTANT!!!!! :
// set #define DEBUG_PINS accordingly (in monitoring.h)
//===============================================================

// PWMEN 54
// DEBUG0Pin 55
// DEBUG1Pin 56
// DEBUG2Pin 57
// DEBUG3Pin 58
// SAMPLE 59
// RDVAL 60
// EN2 61
// RESET 62

const gpioPin_t debugGPIOConf[DEBUG_PINS] = {
		{
				.PinId = (u8)55,
				.PinDirection = gpioDirection_Out
		},
		{
				.PinId = (u8)56,
				.PinDirection = gpioDirection_Out
		},
		{
				.PinId = (u8)57,
				.PinDirection = gpioDirection_Out
		},
		{
				.PinId = (u8)58,
				.PinDirection = gpioDirection_Out
		},
};


#endif
